<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCommentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('comments', function (Blueprint $table) {
            $table->id();
            $table->string('sender_name')->nullable();
            $table->text('comment_text')->nullable();
//            $table->boolean('is_shown')->nullable();
//            $table->unsignedBigInteger('project_id');
//
//            $table->foreign('project_id')
//                ->references('id')
//                ->on('Projects')
//                ->onDelete('cascade');
            $table->timestamps();

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('comments');
    }
}
