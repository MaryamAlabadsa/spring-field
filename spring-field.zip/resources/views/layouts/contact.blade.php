<div class="info">
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <div class="col"><span class="id-color"><i class="fa fa-map-marker"></i></span>128 City Road, London, United Kingdom </div>
                <div class="col"><span class="id-color"><i class="fa fa-clock-o"></i></span>Saturday - Thursday 09:00-19:00</div>
                <div class="col"><span class="id-color"><i class="fa fa-phone"></i></span>⁦+972 56-689-3020⁩</div>
{{--                <div class="col">--}}
{{--                    <div id="lang-selector" class="dropdown">--}}
{{--                        <a href="#" class="btn-selector">English</a>--}}
{{--                        <ul>--}}
{{--                            <li class="active"><a href="#">English</a></li>--}}
{{--                            <li><a href="#">France</a></li>--}}
{{--                            <li><a href="#">Germany</a></li>--}}
{{--                            <li><a href="#">Spain</a></li>--}}
{{--                        </ul>--}}
{{--                    </div>--}}
{{--                </div>--}}

            </div>
            <div class="col-md-4 text-right">
                <!-- social icons -->
                <div class="col social">
                    <a href="https://www.facebook.com/Spring-FIELD-C-LTD-101531909461747"><i class="fa fa-facebook"></i></a>
                    <a href="https://twitter.com/springfltd?s=21&t=9tqLU71TmxLYS2KAHUWeJQ"><i class="fa fa-twitter"></i></a>
                    <a href="https://instagram.com/springfltd?igshid=YWJhMjlhZTc="><i class="fa fa-instagram"></i></a>
                    <a href="https://www.linkedin.com/company/springfltd/"><i class="fa fa-linkedin"></i></a>
                    <a href="https://api.whatsapp.com/send?phone=972566893020"><i class="fa fa-whatsapp"></i></a>
                </div>
                <!-- social icons close -->
            </div>
        </div>
    </div>
</div>
