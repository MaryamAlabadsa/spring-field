<section id="section-fun-facts" class="text-light pt30 pb30 hidden" data-bgcolor="#252a50">
    <div class="container">

        <div class="row">
            <div class="col-md-3 wow fadeIn" data-wow-delay="0">
                <div class="de_count">
                    <h3 class="timer" data-to="8350" data-speed="2500">0</h3>
                    <span>Hours of Works</span>
                </div>
            </div>

            <div class="col-md-3 wow fadeIn" data-wow-delay=".25s">
                <div class="de_count">
                    <h3 class="timer" data-to="240" data-speed="2500">0</h3>
                    <span>Projects Complete</span>
                </div>
            </div>

            <div class="col-md-3 wow fadeIn" data-wow-delay=".5s">
                <div class="de_count">
                    <h3 class="timer" data-to="120" data-speed="2500">0</h3>
                    <span>Feedback Received</span>
                </div>
            </div>

            <div class="col-md-3 wow fadeIn" data-wow-delay=".75s">
                <div class="de_count">
                    <h3 class="timer" data-to="20" data-speed="2500">0</h3>
                    <span>Awards Winning</span>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- section close -->
