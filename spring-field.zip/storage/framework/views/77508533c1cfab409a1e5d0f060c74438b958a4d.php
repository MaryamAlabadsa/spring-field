<section id="section-welcome-2" class="no-top" data-bgcolor="#f8f8f8">
    <div class="container">
        <div class="row mt-40">

            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4">
                    <figure class="pic-hover hover-scale mb20">
                                <span class="center-xy">
                                    <a class="image-popup" href="<?php echo e($service->image_link); ?>">
                                        <i class="fa fa-image btn-action btn-action-hide"></i></a>
                                </span>
                        <span class="bg-overlay"></span>
                        <img src="<?php echo e($service->image_link); ?>" style="width: 360px;height: 240px;" class="img-responsive" alt="">
                    </figure>
                    <h3 style="height: 48px"><?php echo e($service->title); ?></h3>
                    <p>
                        <?php echo e($service->Brief); ?>

                        <a href="#section-services" data-toggle="collapse"
                           data-target="#collapse<?php echo e($service->id); ?>" class="read_more mt10"
                           style="border: transparent;background: transparent;"
                           id="read_more_btn">read more <i class="fa fa-chevron-right id-color"></i></a>
                    </p>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

</section>

<?php /**PATH E:\tamer\spring-field\resources\views/layouts/slider-2.blade.php ENDPATH**/ ?>