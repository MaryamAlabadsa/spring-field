<section id="section-news">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h2>Latest News<span class="tiny-border"></span></h2>
            </div>


            <ul id="blog-carousel" class="blog-list blog-snippet">
                <?php $__currentLoopData = $allNews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="col-md-6 item">
                        <div class="post-content">
                            <div class="date-box">
                                <div class="day"><?php echo e($news->day); ?></div>
                                <div class="month"><?php echo e($news->month); ?></div>
                            </div>

                            <div class="post-text">
                                <button style="font-size: 16px;background: none;border: none;font-style: italic;"
                                        onclick="showNews(this)"><?php echo e($news->title); ?></button>
                                <p class="hide">
                                    <?php echo e($news->description); ?>

                                </p>
                            </div>

                        </div>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </ul>

        </div>
    </div>
</section>

<?php /**PATH E:\tamer\spring-field\resources\views/layouts/sections/home/section-news.blade.php ENDPATH**/ ?>