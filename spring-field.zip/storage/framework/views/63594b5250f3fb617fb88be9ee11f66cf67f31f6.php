<?php $__env->startSection('content'); ?>
    <!-- section begin -->
    <?php echo $__env->make('layouts.slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- section close -->

    <!-- section begin -->
    <?php echo $__env->make('layouts.slider-2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
    <!-- section close -->

    <!-- section begin -->
    <?php echo $__env->make('layouts.sections.home.section-fun-facts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- section begin -->
    <?php echo $__env->make('layouts.sections.home.section-our-story', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.sections.home.section-over-view', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- section close -->


    <!-- content begin -->
    <div id="content">

        <!-- section close -->

        <!-- section close -->
        <?php echo $__env->make('layouts.sections.home.section-how-we-work', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('layouts.sections.home.section_services_details', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- section begin -->
        <?php echo $__env->make('layouts.sections.home.section-portfolio', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- section begin -->
        <?php echo $__env->make('layouts.sections.home.section-comments', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- section close -->

        <!-- section begin -->
        <?php echo $__env->make('layouts.sections.home.section-team', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- section close -->


        <!-- section begin -->


    <?php echo $__env->make('layouts.sections.home.section-news', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('layouts.sections.home.section-contact', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\tamer\spring-field\resources\views/layouts/sections/home/home-index.blade.php ENDPATH**/ ?>