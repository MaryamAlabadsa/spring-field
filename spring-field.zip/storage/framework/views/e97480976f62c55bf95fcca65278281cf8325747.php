





























































<section id="section-portfolio" aria-label="section-portfolio" class="no-top no-bottom"
         style="background-size: cover;">
    <div class="container" style="background-size: cover;">

        <div class="spacer-single" style="background-size: cover;"></div>

        <!-- portfolio filter begin -->
        <div class="row" style="background-size: cover;">
            <div class="col-md-12" style="background-size: cover;">
                <ul id="filters">
                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $title= str_replace(' ', '', trim($service->id))
                        ?>
                        <li><a href="#" data-filter=".<?php echo e($service->id); ?>"><?php echo e($service->title); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <li class="pull-right"><a href="#" data-filter="*" class="selected">All Projects</a></li>
                </ul>

            </div>
        </div>
        <!-- portfolio filter close -->

    </div>

    <div id="gallery" class="gallery full-gallery de-gallery pf_full_width pf_4_cols gallery_border isotope"
         style="position: relative; overflow: hidden; height: 3215px; background-size: cover;">
        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $string = '';
            ?>
            <?php $__currentLoopData = $project->project_service_mm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $s = str_replace(' ', '', trim($s));

                        $string .= $s .' ';
                ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <!-- gallery item -->
            <div class="item <?php echo e($string); ?>"
                 style="position: absolute; left: 0px; top: 0px; transform: translate3d(0px, 0px, 0px); background-size: cover;">
                <div class="picframe" style="height: 258px; background-size: cover;">
                    <a href="/home/<?php echo e($project->id); ?>">
                                <span class="overlay" style="opacity: 0;">
                                    <span class="pf_text">
                                        <span class="project-name"><?php echo e($project->title); ?></span>
                                    </span>
                                </span>
                    </a>
                    <img src="<?php echo e($project->main_image_link); ?>" alt="" style="width: 100%; height: auto;">
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <!-- close gallery item -->
    </div>

</section>
<?php /**PATH E:\tamer\spring-field\resources\views/layouts/sections/home/section-portfolio.blade.php ENDPATH**/ ?>