<section id="section-deco-1" class="no-top no-bottom text-light" data-stellar-background-ratio=".2">
    <div class="color-overlay pt80">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h2 class="wow fadeInUp">What They Says<span class="tiny-border"></span></h2>
                    <ul class="testimonial-list wow fadeIn" style="margin-top: 50px" data-wow-delay=".25s">
                        <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>      <?php echo e($comment->comment_text); ?>

                                <span><?php echo e($comment->sender_name); ?></span>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>

                <div class="col-md-6">
                    <img src="images/misc/team-1.png" class="img-responsive mt-20" alt="">
                </div>

                <div class="clearfix"></div>
            </div>
        </div>
    </div>
</section>
<?php /**PATH E:\tamer\spring-field\resources\views/layouts/sections/home/section-comments.blade.php ENDPATH**/ ?>