<?php $__env->startComponent('mail::message'); ?>
# Introduction

<p>message: <?php echo e($mailData['message']); ?></p>







<?php echo $__env->renderComponent(); ?>
<?php /**PATH E:\tamer\spring-field\resources\views/emails/subscribers.blade.php ENDPATH**/ ?>